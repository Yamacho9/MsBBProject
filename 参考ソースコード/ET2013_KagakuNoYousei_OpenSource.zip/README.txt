This software is released under the MIT License, see LICENSE.txt.
