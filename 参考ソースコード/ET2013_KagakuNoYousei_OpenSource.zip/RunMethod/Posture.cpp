#include "RunMethod/Posture.h"

enum Posture::PostureType Posture::m_current_posture = Posture::VER;

void Posture::changePosture() {
}

Posture::Posture() {}

Posture::~Posture() {}


//Copyright (c) 2014 Kagaku No Yousei. All Rights Reserved.

