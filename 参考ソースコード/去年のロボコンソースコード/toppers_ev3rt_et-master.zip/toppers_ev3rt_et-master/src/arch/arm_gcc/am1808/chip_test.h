/*
 *	テストプログラムのチップ依存定義（AM1808用）
 */

#ifndef TOPPERS_CHIP_TEST_H
#define TOPPERS_CHIP_TEST_H

#include "target_serial.h"

#endif /* TOPPERS_CHIP_TEST_H */
