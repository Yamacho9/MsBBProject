void syslog() {}
void memcpy() {}
void memset() {}
void memcmp() {}
void strlen() {}
void strcat() {}
void strncpy() {}
void strncmp() {}
