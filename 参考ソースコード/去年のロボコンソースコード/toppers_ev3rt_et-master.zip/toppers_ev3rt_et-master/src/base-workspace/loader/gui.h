/*
 * gui.h
 *
 *  Created on: Nov 29, 2014
 *      Author: liyixiao
 */

#pragma once

//#define MSGBOX_BTN_OK (1 << 0)

void show_message_box(const char *title, const char *msg);
