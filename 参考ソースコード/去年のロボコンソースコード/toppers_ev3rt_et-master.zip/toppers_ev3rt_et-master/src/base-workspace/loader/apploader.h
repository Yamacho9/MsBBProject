#pragma once

ER application_load_menu();
void application_terminate_request();
void application_terminate_wait();
